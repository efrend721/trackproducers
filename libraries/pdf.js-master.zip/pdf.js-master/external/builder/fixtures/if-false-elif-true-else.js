'use strict';
//#if FALSE
var a;
//#elif TRUE
var b;
//#else
var c;
//#endif
